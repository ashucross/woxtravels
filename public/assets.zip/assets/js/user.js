$(document).ready(function () {
    /* LOGIN */

    $("#email_cn").click(function () {
        $(".login_view2").show();
        $(".login_view1").hide();
    });

    $("#bck_1").click(function () {
        $(".login_view2").hide();
        $(".login_view1").show();
    });

    $("#nxtotp").click(function () {
        $(".login_view2").hide();
        $(".login_view3").show();
    });

    $("#bck_2").click(function () {
        $(".login_view2").show();
        $(".login_view3").hide();
    });

    /* LOGIN END*/

    $(".barmnu").click(function () {
        $(".menubox").addClass("showmenu");
    });
    $(".closemenu").click(function () {
        $(".menubox").removeClass("showmenu");
    });

    $("[name=tab]").each(function (i, d) {
        var p = $(this).prop("checked");
        //   console.log(p);
        if (p) {
            $("article").eq(i).addClass("on");
        }
    });

    $("[name=tab]").on("change", function () {
        var p = $(this).prop("checked");

        // $(type).index(this) == nth-of-type
        var i = $("[name=tab]").index(this);

        $("article").removeClass("on");
        $("article").eq(i).addClass("on");
    });

    $(".sbt1 ").click(function () {
        $(".sbt1 ").removeClass("activetb");
        $(this).addClass("activetb");
    });

    $(function () {
        $('input[name="daterange"]').daterangepicker(
            {
                opens: "left",
                autoApply: true,
            },
            function (start, end, label) {
                console.log(
                    "A new date selection was made: " +
                        start.format("YYYY-MM-DD") +
                        " to " +
                        end.format("YYYY-MM-DD")
                );
            }
        );
    });
    // $(".dropdown-menu").click(function (event) {
    //     event.stopPropagation();
    // });

    $(function () {
        $('input[name="daterange1"]').daterangepicker(
            {
                singleDatePicker: true,
                opens: "left",
                autoApply: true,
            },
            function (start, end, label) {
                console.log(
                    "A new date selection was made: " +
                        start.format("YYYY-MM-DD") +
                        " to " +
                        end.format("YYYY-MM-DD")
                );
            }
        );
    });

    $('input[name="birthday"]').daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
    });

    $('input[name="birthday"]').val("");
    $('input[name="birthday"]').attr("placeholder", "Date of birth");

    $('input[name="birthday1"]').daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
    });

    $('input[name="birthday1"]').val("");
    $('input[name="birthday1"]').attr("placeholder", "Expiry date of passport");

    //   $(function() {
    //     $('input[name="ckein"]').daterangepicker({
    //         opens: 'left',
    //         autoApply: true,
    //         autoUpdateInput: false,
    //         locale: {
    //           cancelLabel: 'Clear'
    //       }
    //     }, function(start, end, label) {
    //         console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
    //     });
    // });
    //   $('input[name="ckein"]').val('');
    //   $('input[name="ckein"]').attr("placeholder", "Check-In - Check-Out");
    //   $(".ckdte").click(function(){
    //     $(".cktxts").hide();
    //         });

    $(function () {
        $('input[name="ckein"]').daterangepicker({
            autoApply: true,
            autoUpdateInput: false,
            locale: {
                cancelLabel: "Clear",
            },
        });

        $('input[name="ckein"]').on(
            "apply.daterangepicker",
            function (ev, picker) {
                $(this).val(
                    picker.startDate.format("MM/DD/YYYY") +
                        " - " +
                        picker.endDate.format("MM/DD/YYYY")
                );
            }
        );

        $('input[name="ckein"]').on(
            "cancel.daterangepicker",
            function (ev, picker) {
                $(this).val("");
            }
        );
    });

    $(function () {
        $('input[name="daterange2"]').daterangepicker(
            {
                singleDatePicker: true,
                opens: "left",
                autoApply: true,
            },
            function (start, end, label) {
                console.log(
                    "A new date selection was made: " +
                        start.format("YYYY-MM-DD") +
                        " to " +
                        end.format("YYYY-MM-DD")
                );
            }
        );
    });

    $("#mobile_code").intlTelInput({
        initialCountry: "in",
        separateDialCode: true,
        // utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.4/js/utils.js"
    });
});

jQuery(document).ready(($) => {
    $(".quantity").on("click", ".plus", function (e) {
        let _Adult = parseInt($("#qnty-adult").val());
        let _Child = parseInt($("#qnty-child").val());
        let _Infant = parseInt($("#qnty-infant").val());
        let _Total = _Adult + _Child;

        let $input = $(this).prev("input.qty");
        let val = parseInt($input.val());
        let slugId = $input.attr("id");
        switch (slugId) {
            case "qnty-adult":
                if (_Total + 1 <= 9 && _Adult + 1 <= 9) {
                    $input.val(val + 1).change();
                } else {
                    toastr["error"]("Error!", "Only 9 passenger is allowed");
                }
                break;
            case "qnty-child":
                if (_Total + 1 <= 9 && _Child + 1 <= 9) {
                    $input.val(val + 1).change();
                } else {
                    toastr["error"]("Error!", "Only 9 passenger is allowed");
                }
                break;
            case "qnty-infant":
                if (_Infant + 1 <= _Adult) {
                    $input.val(val + 1).change();
                } else {
                    toastr["error"](
                        "Error!",
                        "only " + _Adult + " infant is allowed with adult"
                    );
                }
                break;
        }
    });

    $(".quantity").on("click", ".minus", function (e) {
        let _Adult = parseInt($("#qnty-adult").val());
        let _Child = parseInt($("#qnty-child").val());
        let _Infant = parseInt($("#qnty-infant").val());
        let _Total = _Adult + _Child;
        let $input = $(this).next("input.qty");
        var val = parseInt($input.val());
        let slugId = $input.attr("id");
        let vall = 0;

        switch (slugId) {
            case "qnty-adult":
                if (_Total <= 9 && _Adult <= 9) {
                    if (_Adult - 1 < _Infant) {
                        $("#qnty-infant").val("0");
                    }
                } else {
                    toastr["error"]("Error!", "Only 9 passenger is allowed");
                }
                break;
            case "qnty-child":
                if (_Total <= 9 && _Child <= 9) {
                } else {
                    toastr["error"]("Error!", "Only 9 passenger is allowed");
                }
                break;
            case "qnty-infant":
                if (_Infant <= _Adult) {
                } else {
                    toastr["error"](
                        "Error!",
                        "only " + _Adult + " infant is allowed with adult"
                    );
                }
                break;
        }

        if (slugId == "qnty-adult") {
            vall = 1;
        }
        if (val > vall) {
            $input.val(val - 1).change();
        }
    });
});

// --------Calculation End
$(document).ready(function () {
    $("#BlackButton").click(switchGray);
    $("#whiteButton").click(switchWhite);
    $("#darkblue").click(switchBlue);

    function switchGray() {
        $("body").attr("class", "Black");
    }

    function switchWhite() {
        $("body").attr("class", "white");
    }

    function switchBlue() {
        $("body").attr("class", "darkblue");
    }

    $(".cogbtn").click(function () {
        $(".boxthems").toggleClass("showcog");
    });

    $(".slider-for").slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: ".slider-nav",
    });
    $(".slider-nav").slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        asNavFor: ".slider-for",
        dots: true,
        centerMode: true,
        focusOnSelect: true,
    });

    $("#flip").click(function () {
        $("#panel").slideToggle("slow");
    });
});

$(document).ready(function () {
    //Workaround - Safari/Ios - does not respect the <option hidden> attribute
    //Momentarily remove the hidden option element when the user clicks a select element.
    //Re-Add it after iOS has generated its selection popover

    var hiddenOption; //Holds the option element we want to be non-selectable extra option)
    var timers = []; //Collect setTimout timers

    function returnOptionToSelect(element) {
        if ($(element).children("[data-ioshidden]").length > 0) {
            //It's already there. Do nothing.
        } else {
            $(element).prepend(hiddenOption); //Put it back
        }
    }

    $("#jQueryWorkaroundForm select").on("touchstart touchend", function (e) {
        if ($(e.target).data("has-been-changed")) {
            //don't do anything
        } else {
            if ($(e.target).children("[data-ioshidden]").length > 0) {
                hiddenOption = $(e.target).children("[data-ioshidden]");
                $(hiddenOption).remove();
            }
            timers.push(setTimeout(returnOptionToSelect, 35, $(e.target))); //Nice short interval that's largely imperceptible, but long enough for the popover to generate
        }
    });

    $("#jQueryWorkaroundForm select").on("input", function (e) {
        if ($(e.target).data("has-been-changed")) {
            //do nothing
        } else {
            $(e.target).data("has-been-changed", true);
            if (
                navigator.maxTouchPoints &&
                navigator.userAgent.includes("Safari") &&
                !navigator.userAgent.includes("Chrome")
            ) {
                $(e.target).prop("selectedIndex", e.target.selectedIndex + 1); //Need to bump the index +1 on ios
            }
            //make sure the option is gone
            for (var x in timers) {
                clearTimeout(x);
            }
            timers = [];
            if ($(e.target).children("[data-ioshidden]").length > 0) {
                $(e.target).children("[data-ioshidden]").remove();
            }
            hiddenOption = undefined; //throw away the option so it can't get put back
        }
    });

    $("#jQueryWorkaroundForm select").on(
        "blur focusout touchcancel",
        function (e) {
            if ($(e.target).data("has-been-changed")) {
                //The user selected an option. Don't put the element back.
            } else {
                //The user did not select an option.
                if ($(e.target).children("[data-ioshidden]").length > 0) {
                    //It's already there. Do nothing.
                } else {
                    $(e.target).prepend(hiddenOption); //Put it back
                }
            }
        }
    );
});
