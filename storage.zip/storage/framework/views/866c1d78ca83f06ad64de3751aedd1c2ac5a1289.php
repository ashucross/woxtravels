<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageContent'); ?>
<?php
$booking_response = json_decode($hotel_booking_details->booking_response);
$paxs = $booking_response->booking->hotel->rooms[0]->paxes;
?>
<div class="container">
    <div class="detailsmain">
        <div class="leftmain_rv">
            <div class="booking_cm_txt text-center brdb">
                <span><img src="images/bok-conf-icon.png" alt="" class="img-res" /></span>
                <span>Your Booking Successfully Completed.</span>
                <span>Congratulations! your Booking has been Confirmed.</span>
                <span> Thank you</span>
            </div>

            <div class="detailscm brdb">
                <h3>Mr <?php echo e($booking_response->booking->holder->name); ?> <?php echo e($booking_response->booking->holder->surname); ?>

                </h3>
                <ul class="clearfix list_ds">

                    <li>
                        <label>Phone No.</label>
                        <span><?php echo e($hotel_booking_details->mobile); ?></span>
                    </li>
                    <li>
                        <label>Email Id</label>
                        <span><?php echo e($hotel_booking_details->email); ?></span>
                    </li>


                    <li>
                        <label>Booking Date</label>
                        <span><?php echo e(date('F-Y-d', strtotime($hotel_booking_details->booking_date))); ?></span>
                    </li>

                </ul>

            </div>


            <div class="psg_details brdb">
                <div class="dts_heading">
                    <h1 class="mtprew1"><i class="fa fa-user mr-1"></i>Passenger Details</h1>
                </div>
                <div class="tbdetails table-responsive">
                    <table class="table tbds_c">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th> Pax Type</th>
                                <th>Name</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $paxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $type = $pax->type =='AD' ? 'Adult' : 'Child';
                            ?>
                            <tr>
                                <td><?php echo e($pax->roomId); ?></td>
                                <td><?php echo e($type); ?></td>
                                <td>Mr <?php echo e($pax->name); ?> <?php echo e($pax->surname); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


            </div>


        </div>



        <div class="rightmain_rv ">
            <div class="pritotal_main  mtprew1">
                <div class="bookingrfs  pdbox_wht">
                    <h6>Your booking reference no
                        <strong><?php echo e($booking_response->booking->reference); ?></strong>
                    </h6>
                    <h6 class="mt-3">Booking Date & Time
                        <span><?php echo e(date('F-Y-d H:A', strtotime($hotel_booking_details->booking_date))); ?></strong>
                    </h6>

                </div>

                <div class="farebox whitebrd ">
                    <h3><i class="fa fa-money mr-1"></i>PAYMENT RECEIPT</h3>
                    <div class="paybx cngfet">

                        <ul class="basefareul">

                            <li><span>Adults x <?php echo e($booking_response->booking->hotel->rooms[0]->rates[0]->adults); ?></span></li>

                            <li><span>Base Fare</span><span><b><i class="fa fa-dollar"></i>&nbsp;<?php echo e($booking_response->booking->hotel->rooms[0]->rates[0]->net); ?><sup>
                                        </sup></b></span></li>

                            <li><span>Discount</span><span><b><i class="fa fa-dollar"></i>&nbsp;0<sup> </sup></b></span>
                            </li>

                            <li><span>Total Fare</span><span><b><i class="fa fa-dollar"></i>&nbsp;<?php echo e($booking_response->booking->hotel->rooms[0]->rates[0]->net); ?><sup>
                                        </sup></b></span></li>

                        </ul>

                    </div>





                    <div class="paybx brdtopd">

                        <ul class="basefareul">



                            <li><span><b>Total</b></span><span><b><i class="fa fa-dollar"></i> <?php echo e($booking_response->booking->hotel->rooms[0]->rates[0]->net); ?>.<sup>
                                        </sup></b></span></li>

                        </ul>



                        <div class="upcrt">

                            <span><i class="fa fa-line-chart" aria-hidden="true"></i>&nbsp; <?php echo e($booking_response->booking->hotel->rooms[0]->rates[0]->rateComments); ?>.

                            </span>

                        </div>

                    </div>


                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('homeLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\negi ji\Desktop\woxtravels\resources\views/hotel/hotel-booking-confing.blade.php ENDPATH**/ ?>