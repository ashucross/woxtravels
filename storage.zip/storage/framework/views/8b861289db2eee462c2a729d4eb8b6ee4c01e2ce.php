<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo e($data['_MetaTitle']); ?></title>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->make('includes.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- // for page specific stylesheet -->
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- poplogin -->

    <?php echo $__env->make('includes.popuplogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- poplogin end -->
    <!-- poplanguage -->
    <?php echo $__env->make('includes.popuplanguage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- poplanguage end -->
    <!-- Page Content Start-->
    <?php echo $__env->yieldContent('pageContent'); ?>
    <!-- Page Content End -->

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- // for page specific script -->
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH C:\Users\negi ji\Desktop\woxtravels\resources\views/homeLayout.blade.php ENDPATH**/ ?>