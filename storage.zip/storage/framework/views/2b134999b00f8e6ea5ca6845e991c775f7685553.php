<div class="listticket">
    <ul class="tktlist">
        <?php $__currentLoopData = $flightresult['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $searchFlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        // dd($searchFlight);
        ?>
        
        <li class="flight-li trip airlines-<?php echo e($searchFlight['itineraries'][0]['segments'][0]['carrierCode']); ?>"
            price="<?php echo e(number_format($searchFlight['price']['total'])); ?>">
            <div class="largehead">
                <h4>Departure Journey &nbsp;&nbsp;|&nbsp;&nbsp;<span> <?php echo e(date('M d Y',
                        strtotime($searchFlight['itineraries'][0]["segments"][0]['departure']['at']))); ?></h4>
            </div>
            <div class="flexlist">
                <div class="inuot_bx">
                    <div class="tmingtk ">
                        <ul class="dflex_js mbs">
                            <li>
                                <div class="airnm">
                                    <span>
                                        <?php $file =
                                        getFileName($searchFlight['itineraries'][0]["segments"][0]['carrierCode']);
                                        // dd($file);
                                        ?>
                                        <?php if($file): ?>
                                        <img src="<?php echo e($file); ?>" class="img-res"
                                            alt="<?php echo e($searchFlight['itineraries'][0]["segments"][0]['carrierCode']); ?>">
                                        <?php else: ?>
                                        
                                        <?php endif; ?>
                                    </span>
                                    <h6><?php echo e($flightresult['dictionaries']['carriers'][$searchFlight['itineraries'][0]["segments"][0]['carrierCode']]); ?>

                                    </h6>
                                </div>
                            </li>
                            <?php $depaturecountryDetails =
                            getCountryName($flightresult['dictionaries']['locations'][$searchFlight['itineraries'][0]["segments"][0]['departure']['iataCode']]["countryCode"],$searchFlight['itineraries'][0]["segments"][0]['departure']['iataCode']);
                            ?>
                            <li class="tooltip1">
                                <p> <?php echo e(date('H:i',
                                    strtotime($searchFlight['itineraries'][0]["segments"][0]['departure']['at']))); ?>&nbsp;<span>(<?php echo e($searchFlight['itineraries'][0]["segments"][0]['departure']['iataCode']); ?>)</span>
                                </p><span class="blkts"><?php echo e($depaturecountryDetails->country_name); ?> (<?php echo e($depaturecountryDetails->city_name); ?>)</span>
                                <div class="tooltiptext">
                                    <h6><strong><?php echo e(date('H:i',
                                            strtotime($searchFlight['itineraries'][0]["segments"][0]['departure']['at']))); ?> .</strong> <?php echo e(date('M-d-Y',
                                        strtotime($searchFlight['itineraries'][0]["segments"][0]['departure']['at']))); ?>

                                        <span>
                                            <?php echo e($depaturecountryDetails->country_name); ?> (<?php echo e($depaturecountryDetails->city_name); ?>)
                                        </span>
                                    </h6>
                                </div>
                            </li>
                            <li><span class="blkts cnts"><?php echo e(strtolower(str_replace('H','H
                                    ',substr($searchFlight['itineraries'][0]["duration"],
                                    2)))); ?></span>
                                <span class="hrst"></span>
                                <span
                                    class="blkts cnts"><?php echo e((count($searchFlight['itineraries'][0]["segments"])
                                    -1)); ?> Stop</span>
                            </li>
                            <?php $arrivalcountryDetails =
                            getCountryName($flightresult['dictionaries']['locations'][$searchFlight['itineraries'][0]["segments"][(count($searchFlight['itineraries'][0]["segments"])-1)]['arrival']['iataCode']]["countryCode"],$searchFlight['itineraries'][0]["segments"][(count($searchFlight['itineraries'][0]["segments"])-1)]['arrival']['iataCode']);
                            ?>
                            <li class="tooltip1 text-right">

                                <p>

                                    <?php echo e(date('H:i',
                                    strtotime($searchFlight['itineraries'][0]["segments"][(count($searchFlight['itineraries'][0]["segments"])-1)]['arrival']['at']))); ?>&nbsp;<span>(<?php echo e($searchFlight['itineraries'][0]["segments"][(count($searchFlight['itineraries'][0]["segments"])-1)]['arrival']['iataCode']); ?>)</span>
                                </p>
                                <span class="blkts"><?php echo e($arrivalcountryDetails->country_name ??
                                    Null); ?> (<?php echo e($arrivalcountryDetails->city_name ?? Null); ?>)</span>
                                <div class="tooltiptext">
                                    <h6><strong>
                                            <?php echo e($searchFlight['itineraries'][0]["segments"][(count($searchFlight['itineraries'][0]["segments"])-1)]['arrival']['iataCode']); ?>

                                            <?php echo e(date('H:i',
                                            strtotime($searchFlight['itineraries'][0]["segments"][(count($searchFlight['itineraries'][0]["segments"])-1)]['arrival']['at']))); ?> .</strong> <?php echo e(date('M-d-y',
                                        strtotime($searchFlight['itineraries'][0]["segments"][(count($searchFlight['itineraries'][0]["segments"])-1)]['arrival']['at']))); ?>

                                        <span><?php echo e($arrivalcountryDetails->country_name ?? Null); ?>

                                            (<?php echo e($arrivalcountryDetails->city_name ?? Null); ?>)
                                        </span>
                                    </h6>
                                </div>
                            </li>
                        </ul>



                        <?php if(isset($searchFlight['itineraries'][1])): ?>
                        <ul class="dflex_js mbs">
                            <li>
                                <div class="airnm">
                                    <span>
                                        <?php $file =
                                        getFileName($searchFlight['itineraries'][1]["segments"][0]['carrierCode']);
                                        ?>
                                        <?php if($file): ?>
                                        <img src="<?php echo e($file); ?>" class="img-res"
                                            alt="<?php echo e($searchFlight['itineraries'][1]["segments"][0]['carrierCode']); ?>">
                                        <?php else: ?>
                                        
                                        <?php endif; ?>
                                    </span>
                                    <h6><?php echo e($flightresult['dictionaries']['carriers'][$searchFlight['itineraries'][1]["segments"][0]['carrierCode']]); ?>

                                    </h6>
                                </div>
                            </li>
                            <?php $depaturecountryDetails =
                            getCountryName($flightresult['dictionaries']['locations'][$searchFlight['itineraries'][1]["segments"][0]['departure']['iataCode']]["countryCode"],$searchFlight['itineraries'][1]["segments"][0]['departure']['iataCode']);
                            ?>
                            <li class="tooltip1">
                                <p> <?php echo e(date('H:i',
                                    strtotime($searchFlight['itineraries'][1]["segments"][0]['departure']['at']))); ?>&nbsp;<span>(<?php echo e($searchFlight['itineraries'][1]["segments"][0]['departure']['iataCode']); ?>)</span>
                                </p><span class="blkts"><?php echo e($depaturecountryDetails->country_name); ?> (<?php echo e($depaturecountryDetails->city_name); ?>)</span>
                                <div class="tooltiptext">
                                    <h6><strong><?php echo e(date('H:i',
                                            strtotime($searchFlight['itineraries'][1]["segments"][0]['departure']['at']))); ?> .</strong> <?php echo e(date('M-d-Y',
                                        strtotime($searchFlight['itineraries'][1]["segments"][0]['departure']['at']))); ?>

                                        <span>
                                            <?php echo e($depaturecountryDetails->country_name); ?> (<?php echo e($depaturecountryDetails->city_name); ?>)
                                        </span>
                                    </h6>
                                </div>
                            </li>
                            <li><span class="blkts cnts"><?php echo e(strtolower(str_replace('H','H
                                    ',substr($searchFlight['itineraries'][1]["duration"],
                                    2)))); ?></span>
                                <span class="hrst"></span>
                                <span
                                    class="blkts cnts"><?php echo e((count($searchFlight['itineraries'][1]["segments"])
                                    -1)); ?> Stop</span>
                            </li>
                            <?php $arrivalcountryDetails =
                            getCountryName($flightresult['dictionaries']['locations'][$searchFlight['itineraries'][1]["segments"][(count($searchFlight['itineraries'][1]["segments"])-1)]['arrival']['iataCode']]["countryCode"],$searchFlight['itineraries'][1]["segments"][(count($searchFlight['itineraries'][1]["segments"])-1)]['arrival']['iataCode']);
                            ?>

                            <li class="tooltip1 text-right">
                                <p>
                                    <?php echo e(date('H:i',
                                    strtotime($searchFlight['itineraries'][1]["segments"][(count($searchFlight['itineraries'][1]["segments"])-1)]['arrival']['at']))); ?>&nbsp;<span>(<?php echo e($searchFlight['itineraries'][1]["segments"][(count($searchFlight['itineraries'][1]["segments"])-1)]['arrival']['iataCode']); ?>)</span>
                                </p>
                                <span class="blkts"><?php echo e($arrivalcountryDetails->country_name ??
                                    Null); ?> (<?php echo e($arrivalcountryDetails->city_name ?? Null); ?>)</span>
                                 <div class="tooltiptext">
                                    <h6><strong>
                                            <?php echo e($searchFlight['itineraries'][1]["segments"][(count($searchFlight['itineraries'][1]["segments"])-1)]['arrival']['iataCode']); ?>

                                            <?php echo e(date('H:i',
                                            strtotime($searchFlight['itineraries'][1]["segments"][(count($searchFlight['itineraries'][1]["segments"])-1)]['arrival']['at']))); ?> .</strong> <?php echo e(date('M-d-y',
                                        strtotime($searchFlight['itineraries'][1]["segments"][(count($searchFlight['itineraries'][1]["segments"])-1)]['arrival']['at']))); ?>

                                        <span><?php echo e($arrivalcountryDetails->country_name ?? Null); ?>

                                            (<?php echo e($arrivalcountryDetails->city_name ?? Null); ?>)
                                        </span>
                                    </h6>
                                </div>
                            </li>
                        </ul>
                        <?php endif; ?>
                        <div class="bagbx">
                            <span>
                                <img
                                    src="<?php echo e(asset('public/assets/images/Baggage-gray.svg')); ?>">&nbsp;
                                <?php echo e($searchFlight["travelerPricings"][0]["fareDetailsBySegment"][0]["includedCheckedBags"]["weight"]
                                ?? ''); ?> kg Hand baggage&nbsp;&nbsp;|&nbsp;&nbsp;2x 23kg Checked
                                baggage</span>
                        </div>
                    </div>
                </div>
                <div class="prishow">
                    <div class="tbfare">
                        <div class="bookprc">
                            <h5><?php echo e($searchFlight["price"]["currency"] .',
                                '.$searchFlight["price"]['total']); ?></h5>
                            <a href="<?php echo e(url('flightList/details?data='.json_encode($searchFlight,true).'&dictionaries='.json_encode($flightresult['dictionaries']).'&px='.Request::get('px'))); ?>"
                                type="button" class="btnvw"><i
                                    class="fa fa-plane"></i>&nbsp;&nbsp;Book Now</a>
                            


                        </div>
                    </div>
                </div>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\Users\negi ji\Desktop\woxtravels\resources\views/flight/search.blade.php ENDPATH**/ ?>