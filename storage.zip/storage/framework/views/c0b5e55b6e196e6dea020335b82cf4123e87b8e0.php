<?php $__env->startSection('styles'); ?>
<!-- page specific style code here-->
<!-- page specific style code here-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageContent'); ?>
<?php

?>
<div class="container_pd">
    <div class="row">
        <div class="col-sm-12">
            <div class="top_txt_price d-flex justify-content-between align-items-center">
                <div class="left_top_txt">
                    <h1><?php echo e($hotelDetails['name']); ?>

                        <?php
                        $rooms = json_decode($hotelDetails['response_data'])->rooms;
                        $hotelDetailsGet = $details['hoteldetail'];
                        $hotelDetailsFind = $details['hoteldetail']->hotel;
                        // dd($hotelDetailsFind['facilities']);
                        ?>
                        <span class="d-flex ml-2">
                            <?php
                            $explode = explode(" ", $hotelDetails['categoryName']);
                            for($i=0; $i<$explode[0]; $i++) { echo '<i
                                class="fa fa-star"></i>' ; } ?></span>
                    </h1>
                    <span><i class="fa fa-map-marker mr-1"></i><?php echo e($hotelDetails['address']); ?>, <?php echo e($hotelDetails['destinationName']); ?></span>
                </div>
                <div class="price_right">
                    <h2><i class="fa fa-dollar mr-1"></i><?php echo e($hotelDetails['maxRate']); ?></h2>
                    <a href="<?php echo e(url('review')); ?>" class="btn-grad bkd">BOOK THIS NOW</a>
                </div>
            </div>
        </div>

        <div class="col-sm-8">
            <section class="slidertop">
                <?php
                $arrayHotel = $hotelDetailsFind->images;
                $first_ten_keys = array_slice($arrayHotel, 0, 7, true); // extract the first 10 keys
                ?>
                <div class="slider slider-for">
                    <?php if(!empty($first_ten_keys)): ?>
                    <?php $__currentLoopData = $first_ten_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotelImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="mrgbox">
                            <img src="https://photos.hotelbeds.com/giata/<?php echo e($hotelImg->path); ?>"
                                alt="<?php echo e($hotelImg->path); ?>" class="img-res" />
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="slider slider-nav">
                    <?php if(!empty($first_ten_keys)): ?>
                    <?php $__currentLoopData = $first_ten_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotelImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="mrgbox">
                            <img src="https://photos.hotelbeds.com/giata/<?php echo e($hotelImg->path); ?>"
                                alt="<?php echo e($hotelImg->path); ?>" class="img-res" />
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </div>


            </section>

            <div class="bookmark_txt d-flex">
                <a href="#section1" class="active_nav">Description</a>
                <a href="#section2">Rooms</a>
                <a href="#section3">Amenities</a>

            </div>

            <section class="discription_para  page-section" id="section1">
                <h3 class="headingall_ht">Description</h3>
                <div class="hegitbx ara_disp">
                    <p><?php echo e($hotelDetailsFind->description->content ?? ''); ?></p>
                </div>
                
            </section>

            <section class="roombox  page-section" id="section2">
                <h3 class="headingall_ht">Select Your Room</h3>

                <?php if(!empty($rooms)): ?>
                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $room->rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="largebox_listing">
                    <?php
                    $hotelImg = $hotelDetailsFind->images[$key++];
                    ?>
                    <div class="lglist">
                        <div class="list_hotel_img">
                            <div class="lgzoomimg">
                                <a href="#">
                                    <img src="https://photos.hotelbeds.com/giata/<?php echo e($hotelImg->path); ?>"
                                        class="img-res" />
                                </a>
                            </div>
                        </div>

                        <div class="list_hotel_txt">
                            <div class="listing_hd_hotel">
                                <h2><span>
                                        <?php echo e($room->name); ?></span>
                                    <div class="startbx smallstar">
                                        <span><?php echo e($explode[0]); ?>&nbsp;-&nbsp;</span>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </h2>

                                <ul class="listbt_sml">
                                    <li><a href="#"><?php echo e($hotelDetails['address']); ?>, <?php echo e($hotelDetails['destinationName']); ?></a></li>
                                </ul>


                                <ul class="iconsml">

                                    



                                    <li>

                                        <?php echo e($rate->boardName); ?>


                                    </li>
                                </ul>
                                <div class="green_ex">
                                    <span><i class="fa fa-star"></i>&nbsp;<?php echo e($hotelDetailsFind->ranking); ?> (48 reviews)</span>
                                </div>
                            </div>
                        </div>
                        <div class="pribtns">
                            <div class="priceshow">
                                <h3><i class="fa fa-dollar mr-1"></i> <?php echo e($rate->net); ?>

                                    <span>per night</span>
                                </h3>
                                <p>total <i class="fa fa-dollar mr-1"></i>30,000 for 3 nights Tax & fees Inclusive</p>
                            </div>

                            <div class="hotslc">
                                <?php
                                // $rate_key = checkrates($rate->rateKey)['data']->hotel->rooms[0]->rates[0]->rateKey;

                                // $rate_key = $checkrates_response['hotels'][0]['rooms'][0]['rates'][0]['rateKey']
                                // {{ url('book_now/'. $rate->rateKey) }} dd( checkrates($rate->rateKey));die;
                                ?>
                                
                                <form method="post" action="<?php echo e(url('/hotel/review')); ?> ">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="razkey" value="<?php echo e($rate->rateKey); ?>">
                                    <input type="hidden" name="hotelCode" value="<?php echo e($hotelDetails['code']); ?>">
                                    
                                    <button type="submit" data-id="<?php echo e($rate->rateKey); ?>" data-hotel=<?php echo e($hotelDetails['code']); ?> class="btn-grad ftbtn_src booked_btn">Book Now<i
                                            class="fa fa-angle-right ml5" aria-hidden="true"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
            <?php endif; ?>
            <section class="Amenitiesbx page-section" id="section3">
                <?php if(isset($hotelDetailsFind->facilities)): ?>
                <div class="amtbox">
                    <h3 class="headingall_ht">Amenities</h3>

                    <div class="amt_icon d-flex flex-wrap">
                        <?php
                              $first_ten_keys = array_slice(array_reverse($hotelDetailsFind->facilities), 0, 17, true); // extract the first 10 keys
                        ?>
                    <?php $__currentLoopData = $first_ten_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    // dd($hotelDetailsFind);
                    switch ($facilities->facilityCode) {
                        case '550':
                            # code...
                            $img ='assets/images/Wifi_b.svg';
                            break;
                        case '130':
                            # code...
                            $img ='assets/images/Minibar_b.svg';
                            break;

                        default:
                            # code...
                            $img ='assets/images/Bathrobes_b.svg';
                            break;
                    }
                    ?>
                        <div class="amities_rpt d-flex">
                            <span class="imgblack"><img src="<?php echo e(url($img)); ?>" alt=""
                                    class="imgres " /></span>
                            <span class="imagewhite"><img src="<?php echo e(url($img)); ?>" alt=""
                                    class="imgres " /></span>
                            <h3><?php echo e($facilities->description->content); ?></h3>
                            
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      
                    </div>

                </div>
                <?php endif; ?>


                <?php if(isset($hotelDetailsFind->interestPoints)): ?>
                <div class="nrs_box">
                    <h3 class="headingall_ht">Nearest Essentials</h3>
                    <div class="boxnear_full">
                        <div class="nearfield d-flex flex-wrap ">
                            <?php $__currentLoopData = $hotelDetailsFind->interestPoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="boxnear_txt">
                                <h4><?php echo e($item->poiName); ?></h4>
                                <span>
                                    <span><?php echo e($item->distance); ?> M</span>
                                </span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>

                </div>
                <?php endif; ?>
            </section>
        </div>



        <div class="col-sm-4 pl0 changehd">

            <section class="htolst position-relative clearfix">

                <div class="tabsearh_input">

                    <div class="boxsearching ">

                        <div class="">

                            <div class="search_des  ">

                                <div class="Fromwhere position-relative">



                                    <div class="position-relative">

                                        <span class="iconint"><i class="fa fa-map-marker"></i></span>

                                        <input type="text" class="input_src leftri input_hgt"
                                            placeholder="Where are you going?" data-toggle="dropdown" />



                                        <div class="dropdown-menu drp_plane">

                                            <div class="plane_list">

                                                <span>Top Cities</span>

                                                <ul>

                                                    <li>

                                                        <div class="fli_name"><i class="fa fa-hotel"></i> Delhi

                                                        </div>

                                                        <div class="airport_name"><span>1214
                                                                properties</span><span>India</span></div>

                                                    </li>

                                                    <li>

                                                        <div class="fli_name"><i class="fa fa-hotel"></i> Mumbai

                                                        </div>

                                                        <div class="airport_name"><span>1214
                                                                properties</span><span>India</span></div>

                                                    </li>

                                                    <li>

                                                        <div class="fli_name"><i class="fa fa-hotel"></i> Bengaluru

                                                        </div>

                                                        <div class="airport_name"><span>1720
                                                                properties</span><span>India</span></div>

                                                    </li>





                                                </ul>

                                            </div>

                                        </div>

                                    </div>



                                </div>





                            </div>



                            <div class="search_date ht_width_dt">







                                <div class="position-relative ">



                                    <span class="iconint"><i class="fa fa-calendar"></i></span>



                                    <input aut type="text" name="ckein" placeholder="Check-In - Check-Out"
                                        class="input_src  input_hgt ">



                                </div>



                            </div>




                            <div class="search_adult ht_width_tr">



                                <!-- <h3 class="search_title">Travelers</h3> -->



                                <div class="position-relative " data-toggle="dropdown">



                                    <span class="iconint"><i class="fa fa-user-o"></i></span>



                                    <input aut type="text" value="2 adults - 10 children - 1 room"
                                        class="input_src input_hgt ups arrowus">



                                    <!-- <span class="ar_tv"><i class="ml-2 fa fa-angle-down"></i></span> -->



                                    <div class="dropslct">



                                        <div class="dropdown-menu dropdown-menu-right">

                                            <div class="htlad">

                                                <div class="qty_box">

                                                    <div class=" d-flex justify-content-between align-items-center">



                                                        <span>Adult:



                                                        </span>



                                                        <div id='myform' method='POST' class='quantity' action='#'>



                                                            <input type='button' value='-' class='qtyminus minus'
                                                                field='quantity' />



                                                            <input type='text' name='quantity' value='0' class='qty' />



                                                            <input type='button' value='+' class='qtyplus plus'
                                                                field='quantity' />



                                                        </div>







                                                    </div>



                                                </div>





                                                <div class="qty_box">

                                                    <div class=" d-flex justify-content-between align-items-center">



                                                        <span>Child:

                                                            <span class="agetxt">Ages 0 - 17</span>

                                                        </span>



                                                        <div id='myform' method='POST' class='quantity' action='#'>



                                                            <input type='button' value='-' class='qtyminus minus'
                                                                field='quantity' />



                                                            <input type='text' name='quantity' value='0' class='qty' />



                                                            <input type='button' value='+' class='qtyplus plus'
                                                                field='quantity' />



                                                        </div>



                                                    </div>

                                                    <div class="d-flex box_child flex-wrap">

                                                        <div class="childxd">

                                                            <select>
                                                                <option hidden>
                                                                    Age needed
                                                                </option>

                                                                <option value="0" selected="">0 years old</option>
                                                                <option value="1">1 year old</option>
                                                                <option value="2">2 years old</option>
                                                                <option value="3">3 years old</option>
                                                                <option value="4">4 years old</option>
                                                                <option value="5">5 years old</option>
                                                                <option value="6">6 years old</option>
                                                                <option value="7">7 years old</option>
                                                                <option value="8">8 years old</option>
                                                                <option value="9">9 years old</option>
                                                                <option value="10">10 years old</option>
                                                                <option value="11">11 years old</option>
                                                                <option value="12">12 years old</option>
                                                                <option value="13">13 years old</option>
                                                                <option value="14">14 years old</option>
                                                                <option value="15">15 years old </option>
                                                                <option value="16">16 years old</option>
                                                                <option value="17">17 years old</option>

                                                            </select>

                                                        </div>

                                                        <div class="childxd">

                                                            <select>
                                                                <option hidden>
                                                                    Age needed
                                                                </option>

                                                                <option value="0" selected="">0 years old</option>
                                                                <option value="1">1 year old</option>
                                                                <option value="2">2 years old</option>
                                                                <option value="3">3 years old</option>
                                                                <option value="4">4 years old</option>
                                                                <option value="5">5 years old</option>
                                                                <option value="6">6 years old</option>
                                                                <option value="7">7 years old</option>
                                                                <option value="8">8 years old</option>
                                                                <option value="9">9 years old</option>
                                                                <option value="10">10 years old</option>
                                                                <option value="11">11 years old</option>
                                                                <option value="12">12 years old</option>
                                                                <option value="13">13 years old</option>
                                                                <option value="14">14 years old</option>
                                                                <option value="15">15 years old </option>
                                                                <option value="16">16 years old</option>
                                                                <option value="17">17 years old</option>

                                                            </select>

                                                        </div>



                                                    </div>

                                                    <div class="ht_qt_txt">
                                                        <p>To find you a place to stay that fits your entire group along
                                                            with correct prices, we need to know how old your children
                                                            will be at check-out</p>
                                                    </div>

                                                </div>



                                                <div class="qty_box">

                                                    <div class="d-flex justify-content-between align-items-center">



                                                        <span>Rooms

                                                        </span>



                                                        <div id='myform' method='POST' class='quantity' action='#'>



                                                            <input type='button' value='-' class='qtyminus minus'
                                                                field='quantity' />



                                                            <input type='text' name='quantity' value='0' class='qty' />



                                                            <input type='button' value='+' class='qtyplus plus'
                                                                field='quantity' />



                                                        </div>



                                                    </div>






                                                </div>

                                            </div>



                                            <div class="btntv">

                                                <button type="submit" class="btn-grad ftbtn_src">Done</button>

                                            </div>



                                        </div>



                                    </div>



                                </div>











                            </div>






                            <div class="searchbtn d-flex">



                                <button type="submit" class="btn-grad ftbtn_src"><i class="fa fa-paper-plane-o mr-2"
                                        aria-hidden="true"></i>Seach Hotel</button>

                            </div>

                        </div>







                    </div>



                </div>

            </section>
            <div class="mapbox">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15544.320449561204!2d80.28291785!3d13.094109150000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a526f509f4372af%3A0xb24f67e09b80003f!2sGeorge%20Town%2C%20Chennai%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1665567535064!5m2!1sen!2sin"
                    allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    jQuery(function($) {
            $('.moreless').on('click', function() {
                var $el = $(this),
                    textNode = this.lastChild;
                $el.find('span').toggleClass('fa-angle-down fa-angle-up');
                textNode.nodeValue = '' + ($el.hasClass('moreless') ? 'View Less' : ' View More ')
                $el.toggleClass('moreless');
            });
        });

        $(document).ready(function() {
            // $('.booked_btn').click(function(event) {
            //     event.preventDefault();
            //     const razkey  = $(this).data('id');
            //     const hotelCode  = $(this).data('hotel');

            //     $.ajax({
            //     url: '/book_now',
            //     type: 'Post',
            //     headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            //     data: {
            //         razkey: razkey,
            //         hotelCode: hotelCode,
            //     },
            //     dataType:'json',
            //     beforeSend: function (msg) {
            //         $(this).html(
            //             '<i class="fa fa-spinner fa-spin"></i> wait..'
            //         );
            //         $(this).prop("disabled", true);
            //     },
            //     success: function (response) {
            //         $(this).prop("disabled", false);
            //         console.log(response);
            //         if (response.status == 200) {
            //             $.each(response.data, function (index, element) {
            //                 $("#view-account-information-" + index).html(
            //                     element
            //                 );
            //             });

            //             $("body .view-account-information").show().fadeIn(200);
            //             toastr["success"](
            //                 "Success!",
            //                 "Account Information has been updated!"
            //             );
            //         }
            //     },
            // });
            })
            $(".paraclick").click(function() {
                $(".para_dis").toggleClass("hegitbx");
            });



            $(".bookmark_txt>a").click(function() {
                if (location.pathname.replace(/^\//, "") == this.pathname.replace(/^\//, "") && location.hostname == this.hostname) {
                    var target = $(this.hash);
                    target = target.length ? target : $("[name=" + this.hash.slice(1) + "]");
                    if (target.length) {
                        $("html, body").animate({
                            scrollTop: target.offset().top - 80
                        }, 1000);
                        return false;
                    }
                }
            });
            $(window)
                .scroll(function() {
                    var scrollDistance = $(window).scrollTop();
                    $(".page-section").each(function(i) {
                        if ($(this).position().top - 100 <= scrollDistance) {
                            $(".bookmark_txt .active_nav").removeClass("active_nav");
                            $(".bookmark_txt>a").eq(i).addClass("active_nav");
                        }
                    });
                })
                .scroll();
        });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('homeLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\negi ji\Desktop\woxtravels\resources\views/hotel/hotelDetails.blade.php ENDPATH**/ ?>