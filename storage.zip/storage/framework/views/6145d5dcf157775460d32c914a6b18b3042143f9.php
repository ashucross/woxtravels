<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/slick-theme.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/slick.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/daterangepicker.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/css/intlTelInput.css">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/User.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/Responsive.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/thems.css')); ?>">
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet" />
<link rel="shortcut icon" href="<?php echo e(asset('public/assets/images/favicon.ico.png')); ?>" type="image/x-icon" /> <?php /**PATH C:\Users\negi ji\Desktop\woxtravels\resources\views/includes/css.blade.php ENDPATH**/ ?>