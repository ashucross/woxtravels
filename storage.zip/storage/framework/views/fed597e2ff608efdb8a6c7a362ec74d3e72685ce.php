<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link <?php echo e($data['_Flight']); ?>"  href="<?php echo e(url('')); ?>">Flight</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e($data['_Hotel']); ?>" href="<?php echo e(url('hotel')); ?>">Stays</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e($data['_Packages']); ?>" href="<?php echo e(url('packages')); ?>">Attractions</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e($data['_Visa']); ?>" href="<?php echo e(url('visa')); ?>">Visa</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e($data['_Insurance']); ?>" href="<?php echo e(url('insurance')); ?>">Insurance</a>
    </li>
    
    <li class="nav-item">
        <a class="nav-link <?php echo e($data['_Car']); ?>" href="<?php echo e(url('car-rentals')); ?>">Car Rentals</a>
    </li>
</ul><?php /**PATH C:\Users\negi ji\Desktop\woxtravels\resources\views/includes/nav.blade.php ENDPATH**/ ?>