@extends('homeLayout')
@section('styles')
<!-- page specific style code here-->

<!-- page specific style code here-->
@endsection
@section('pageContent')
<div class="container_pd scrlh">
    <div class="row">
        <div class="col-sm-12">
            <div class="top_txt_price d-flex justify-content-between align-items-center">
                <div class="left_top_txt">
                    <h1>Arabian Delights</h1>
                    <h6>4 Nights / 5 Days</h6>
                    <br>
                    <span>3Night Dubai+ 1Night Abudhabi (Complimentry)</span>
                </div>
                <div class="price_right">
                    <h2>
                        <i class="fa fa-dollar mr-1"></i>25,447
                    </h2>
                    <a href="#" class="btn-grad bkd">BOOK THIS NOW</a>
                </div>
            </div>
        </div>
        <div class="col-sm-12">
            <div class="row">
                <div class="col-sm-9">
                    <section class="slidertop">
                        <div class="slider slider-for">
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                        </div>
                        <div class="slider slider-nav">
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                            <div>
                                <div class="mrgbox">
                                    <img src="{{asset('public/assets/images/hotel-big-1.png')}}" alt="" class="img-res" />
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <div class="col-sm-3">
                    <div class="dwn_ls">
                        <a href="#">
                            <i class="fa fa-download mr-1"></i>Download Itinerary </a>
                        <span>Share</span>
                        <a href="#">
                            <i class="fa fa-facebook mr-1"></i>Facebook </a>
                        <a href="#">
                            <i class="fa fa-whatsapp mr-1"></i>Whats App </a>
                        <a href="#">
                            <i class="fa fa-twitter mr-1"></i>Twitter </a>
                        <a href="#">
                            <i class="fa fa-linkedin mr-1"></i>Linkedin </a>
                    </div>
                </div>
            </div>
            <div class="bookmark_txt d-flex">
                <a href="#section1" class="active_nav">Overview</a>
                <a href="#section2">Inclusion</a>
                <a href="#section3">Itinerary</a>
                <a href="#section4">Hotels</a>
                <a href="#section5">Flights</a>
                <a href="#section6">Add on Tours</a>
                <a href="#section7">Terms & Condition</a>
            </div>
            <section class="discription_para  page-section" id="section1">
                <h3 class="headingall_ht">Description</h3>
                <div class="hegitbx para_dis">
                    <p>Proceed for Abu Dhabi city Tour which includes Grand Mosque visit, Emirates Palace(Photo stop), Dates market where you can shop 125 varieties of dates,en route Cornice Beach, Yas Mall, Ferrari world(Photo stop). You can also experience Ferrari World (Optional), discover thrilling rollercoaster’s, live shows, interactive games, and displays. </p>
                    <p>There's something for everyone at this thrilling theme park. After this you will be transfer to Dubai.</p>
                </div>
                <button id="moreless1" class="ml_btn moreless paraclick">
                    <span class="fa fa-angle-down"></span> View More </button>
            </section>
            <section class="roombox  page-section" id="section2">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="Inclusion_tx">
                            <h3 class="headingall_ht">Inclusion</h3>
                            <ul>
                                <li>1 Night accommodation in Florence/Pisa</li>
                                <li>1 Night accommodation in Venice/Padua</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="Inclusion_tx">
                            <h3 class="headingall_ht">Exclusion</h3>
                            <ul>
                                <li>1 Night accommodation in Florence/Pisa</li>
                                <li>1 Night accommodation in Venice/Padua</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>
            <section class="roombox  page-section" id="section3">
                <div class="Itinerary_bx">
                    <h3 class="headingall_ht">Itinerary</h3>
                    <ul class="cbp_tmtimeline">
                        <li>
                            <time class="cbp_tmtime" datetime="">
                                <span>Day</span>
                            </time>
                            <div class="cbp_tmicon"> 1 </div>
                            <div class="cbp_tmlabel">
                                <h4>New Delhi to Abu Dhabi</h4>
                                <ul type="disc">
                                    <li>Arrive at Abu Dhabi Airport, meet &amp; assist with our representative who will transfer you to your preferred choice of hotel in Abu Dhabi <o:p></o:p>
                                    </li>
                                    <li>Overnight Stay at your preferred choice ofÂ&nbsp; Hotel</li>
                                </ul>
                                <div class="itinery_meals">
                                    <h6>Meals:</h6>
                                    <ul class="bullets">
                                        <li>
                                            <i class="fa fa-cutlery"></i>
                                        </li>
                                        <li>Dinner</li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li>
                            <time class="cbp_tmtime" datetime="">
                                <span>Day</span>
                            </time>
                            <div class="cbp_tmicon"> 2 </div>
                            <div class="cbp_tmlabel">
                                <h4>Abu Dhabi - Dubai (Optional – Ferrari World)</h4>
                                <ul>
                                    <li>Breakfast at Hotel</li>
                                    <li>Proceed for Abu Dhabi city Tour which includes Grand Mosque visit, Emirates Palace(Photo stop), Dates market where you can shop 125 varieties of dates,en route Cornice Beach, Yas Mall, Ferrari world(Photo stop). You can also experience Ferrari World (Optional), discover thrilling rollercoasterâ??s, live shows, interactive games, and displays. There's something for everyone at this thrilling theme park. After this you will be transfer to Dubai.</li>
                                    <li>Overnight Stay at your preferred choice of&nbsp; Hotel <br>
                                    </li>
                                </ul>
                                <div class="itinery_meals">
                                    <h6>Meals:</h6>
                                    <ul class="bullets">
                                        <li>
                                            <i class="fa fa-cutlery"></i>
                                        </li>
                                        <li>Breakfast</li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </section>
            <section class="roombox  page-section" id="section4">
                <h3 class="headingall_ht">Hotel Details</h3>
                <div class="largebox_listing">
                    <div class="lglist">
                        <div class="list_hotel_img">
                            <div class="lgzoomimg">
                                <a href="#">
                                    <img src="{{asset('public/assets/images/Hera.jpg')}}" class="img-res" />
                                </a>
                            </div>
                        </div>
                        <div class="list_hotel_txt">
                            <div class="listing_hd_hotel">
                                <h2>
                                    <span> Deluxe Twin Room</span>
                                    <div class="startbx smallstar">
                                        <span>5&nbsp;-&nbsp;</span>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </h2>
                                <ul class="listbt_sml">
                                    <li>
                                        <a href="#">Cayici Mahallesi, Izmit Cd. No 44, Sapanca, 54600, Sakarya</a>
                                    </li>
                                </ul>
                                <ul class="iconsml">
                                    <li>
                                        <span>
                                            <img src="{{asset('public/assets/images/Pool.png')}}" class="img-res" />
                                        </span>
                                        <span>Pool</span>
                                    </li>
                                    <li>
                                        <span>
                                            <img src="{{asset('public/assets/images/FreeParking.png')}}" class="img-res" />
                                        </span>
                                        <span>Free Parking</span>
                                    </li>
                                    <li>
                                        <span>
                                            <img src="{{asset('public/assets/images/Spa.png')}}" class="img-res" />
                                        </span>
                                        <span>Spa</span>
                                    </li>
                                    <li>
                                        <span>
                                            <img src="{{asset('public/assets/images/Gym.png')}}" class="img-res" />
                                        </span>
                                        <span>Gym</span>
                                    </li>
                                    <li>
                                        <span>
                                            <img src="{{asset('public/assets/images/Restaurant.png')}}" class="img-res" />
                                        </span>
                                        <span>Restaurant</span>
                                    </li>
                                    <li>
                                        <span>
                                            <img src="{{asset('public/assets/images/Bar.png')}}" class="img-res" />
                                        </span>
                                        <span>Bar</span>
                                    </li>
                                </ul>
                                <div class="green_ex">
                                    <span>
                                        <i class="fa fa-star"></i>&nbsp;4.77 (48 reviews) </span>
                                </div>
                            </div>
                        </div>
                        <div class="pribtns">
                            <div class="hotslc">
                                <p>Included in trip</p>
                                <a href="#" class="btn-grad ftbtn_src">Upgrade Hotel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="roombox  page-section" id="section5">
                <h3 class="headingall_ht">Flight Details</h3>
                <div class="listticket dptxts">
                    <h4>Departure</h4>
                    <ul class="tktlist">
                        <li class="trip" style="display: list-item;">
                            <div class="largehead">
                                <h4>Departure Journey &nbsp;&nbsp;|&nbsp;&nbsp; <span> Sep 21 2022</span>
                                </h4>
                            </div>
                            <div class="flexlist">
                                <div class="inuot_bx">
                                    <div class="tmingtk ">
                                        <ul class="dflex_js mbs">
                                            <li>
                                                <div class="airnm">
                                                    <span>
                                                        <img src="https://travel24hr.com/img/airline/AI.gif" class="img-res" alt="AI">
                                                    </span>
                                                    <h6>AIR INDIA</h6>
                                                </div>
                                            </li>
                                            <li class="tooltip1">
                                                <p> 06:10&nbsp; <span>(DEL)</span>
                                                </p>
                                                <span class="blkts">India (Delhi)</span>
                                                <div class="tooltiptext">
                                                    <h6>
                                                        <strong>06:10 .</strong> Sep-21-2022 <span> India (Delhi) </span>
                                                    </h6>
                                                </div>
                                            </li>
                                            <li>
                                                <span class="blkts cnts">2h 45m</span>
                                                <span class="hrst"></span>
                                                <span class="blkts cnts">0 Stop</span>
                                            </li>
                                            <li class="tooltip1 text-right">
                                                <p> 08:55&nbsp; <span>(BLR)</span>
                                                </p>
                                                <span class="blkts">India (Bangalore)</span>
                                                <div class="tooltiptext">
                                                    <h6>
                                                        <strong> BLR 08:55 .</strong> Sep-21-22 <span>India (Bangalore) </span>
                                                    </h6>
                                                </div>
                                            </li>
                                        </ul>
                                        <div class="bagbx">
                                            <span>
                                                <img src="{{asset('public/assets/images/Baggage-gray.svg')}}">&nbsp; 25 kg Hand baggage&nbsp;&nbsp;|&nbsp;&nbsp;2x 23kg Checked baggage </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="listticket dptxts">
                    <h4>Return</h4>
                    <ul class="tktlist">
                        <li class="trip" style="display: list-item;">
                            <div class="largehead">
                                <h4>Departure Journey &nbsp;&nbsp;|&nbsp;&nbsp; <span> Sep 21 2022</span>
                                </h4>
                            </div>
                            <div class="flexlist">
                                <div class="inuot_bx">
                                    <div class="tmingtk ">
                                        <ul class="dflex_js mbs">
                                            <li>
                                                <div class="airnm">
                                                    <span>
                                                        <img src="https://travel24hr.com/img/airline/AI.gif" class="img-res" alt="AI">
                                                    </span>
                                                    <h6>AIR INDIA</h6>
                                                </div>
                                            </li>
                                            <li class="tooltip1">
                                                <p> 06:10&nbsp; <span>(DEL)</span>
                                                </p>
                                                <span class="blkts">India (Delhi)</span>
                                                <div class="tooltiptext">
                                                    <h6>
                                                        <strong>06:10 .</strong> Sep-21-2022 <span> India (Delhi) </span>
                                                    </h6>
                                                </div>
                                            </li>
                                            <li>
                                                <span class="blkts cnts">2h 45m</span>
                                                <span class="hrst"></span>
                                                <span class="blkts cnts">0 Stop</span>
                                            </li>
                                            <li class="tooltip1 text-right">
                                                <p> 08:55&nbsp; <span>(BLR)</span>
                                                </p>
                                                <span class="blkts">India (Bangalore)</span>
                                                <div class="tooltiptext">
                                                    <h6>
                                                        <strong> BLR 08:55 .</strong> Sep-21-22 <span>India (Bangalore) </span>
                                                    </h6>
                                                </div>
                                            </li>
                                        </ul>
                                        <div class="bagbx">
                                            <span>
                                                <img src="{{asset('public/assets/images/Baggage-gray.svg')}}">&nbsp; 25 kg Hand baggage&nbsp;&nbsp;|&nbsp;&nbsp;2x 23kg Checked baggage </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </section>
            <section class="roombox  page-section" id="section6">
                <h3 class="headingall_ht">Add-Ons</h3>
                <div class="table-responsive mt-3">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>&nbsp;</th>
                                <th>Price</th>
                                <th>Duration</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Mount Jungfrau with Interlaken Orientation</td>
                                <td>
                                    <i class="fa fa-rupee mr-1"></i>5000
                                </td>
                                <td>1 hour</td>
                            </tr>
                            <tr>
                                <td>Lido Show + illumination of Paris (return transfer own)</td>
                                <td>
                                    <i class="fa fa-rupee mr-1"></i>3000
                                </td>
                                <td>1 hour</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
            <section class="roombox  page-section" id="section7">
                <h3 class="headingall_ht">Terms & Condition</h3>
                <div class="tst">
                    <h5>Cancellation Policy:</h5>
                    <p>The following charges are to be applied at the time of cancellation of holiday</p>
                    <br>
                    <p>Booking date to 21 days prior to departure - 25 % of the total holiday cost or a minimum of 15,000 (which ever is higher) per person.</p>
                    <p>Between 20 – 11 days of departure – 50 % of the total holiday cost per person</p>
                    <p>Between 10 – 6 days before departure – 75% of the total holiday cost per person</p>
                    <p>Less than 6 days of departure – 100 % of the total holiday cost per person</p>
                    <br>
                    <p>** Please read the notes t & c below to get full clarity on the same.</p>
                    <br>
                    <h5>Notes (T&C):</h5>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                </div>
            </section>
        </div>
    </div>
</div>
<div class="footer_pattern">
    <img src="{{asset('public/assets/images/patter_f.svg')}}" alt="" class="imgres" />
</div>
@endsection
@section('scripts')

@endsection