@extends('homeLayout')
@section('styles')
<!-- page specific style code here-->

<!-- page specific style code here-->
@endsection
@section('pageContent')
<div class="container">
    <div class="cmsn text-center">
        <img src="{{asset('public/assets/images/comingsoon.png')}}" alt="" class="img-res" />
    </div>
</div>
@endsection
@section('scripts')

@endsection